#ifndef GENETIC_DISPLAY_H_
#define GENETIC_DISPLAY_H_
#include "genetic_core.h"
namespace genetic {
namespace display {
void DrawStr(int pointer);
void DrawStr(std::string str);
}
}
#endif
